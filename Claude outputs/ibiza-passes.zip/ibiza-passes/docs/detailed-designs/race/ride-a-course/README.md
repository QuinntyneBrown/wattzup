# Ride a course

**Requirement:** L2-166 (L1-027). **Decision:** ADR 0032. **Mock:** none changes: the course is drawn
on the canvas of the race scene (`docs/mocks`, the race), whose HUD stands as it is.

A course is a map built in Blender from the class it is modelled after. This design covers building
one and drawing it; the cadence score (L2-167) and a course's place in the catalogue are not in it.

## Building a course

`tools/blender/build_course.py` (see `tools/blender/README.md`) turns `courses/<id>.json`, the
class's plan, into three files.

| Step | Rule |
| --- | --- |
| Stages | Each segment of the plan becomes a stage with the metres it starts and ends at: `duration x cadenceAim / 60 x 5`. |
| Gradient | `(level - mean level) x 1 %`, the mean weighted by metres, eased with a 28 m box filter twice. The lowest point stands 4 m above the sea. |
| Turns | Dealt feature by feature from the seed (straight, sweep, hairpin, ess), weighted by the stage's kind, rejected when the road would come within 46 m of an earlier stretch, when nothing lies ahead of it, or when it strays past 620 m and does not turn for home. Curvature is eased over 20 m, and the eased line is checked again. |
| Road | A sample every 4 m, from 80 m before the start line to 200 m past the finish. |
| Map | The road with kerbs, paint and effort chevrons; an island heightfield that holds the road's height beside it and falls to the sea; the theme's scenery; gates at the start, the finish and the foot of every effort. One mesh a material. |

`<id>.course.json` carries `lengthMetres`, `durationSeconds`, `step`, `startIndex`, `roadHalfWidth`,
`sun` (the light's direction), `stages` (the plan's segments with `start`, `from`, `to`) and `points`
(the centre line, x, y, z in the glb's axes).

## Drawing a course

All of it is in the `world` library; nothing outside it changes.

| File | Role |
| --- | --- |
| `course-worlds.ts` | Names the worlds drawn as courses and where their files are served. No Three.js. |
| `course.ts` | `parseCourse` validates the file. `Course` answers `metresAt(seconds)`, `stageAt(seconds)`, `place(metres, lane)` and `gradeAt(metres)`. No Three.js; unit-tested in `course.spec.ts`. |
| `map-renderer.ts` | `MapRenderer`, the `WorldRenderer` the loader returns. On `start` it imports `CourseRenderer` or `main`'s `ThreeWorldRenderer` by the world's id, and passes every call on. |
| `course-renderer.ts` | `CourseRenderer`: loads the glb and the course file, builds the sky, the lights and the rider, and draws. |
| `merged-cyclist.ts` | Merges the still parts of a cyclist from the kit into a few meshes. |
| `world-renderer-loader.ts` | Returns a `MapRenderer`. It imports neither renderer, so Three.js still loads only when a world starts. |

**Start.** `WebGPURenderer` with its WebGL2 fallback (ADR 0021), then the course file and the glb
together. A failure of either resolves `false`, and `WorldScene` emits `unavailable` as it does for
`main`'s renderer. The scene is compiled (`compileAsync`) and drawn once at the start line before
`start` resolves, so the ride's first frame compiles nothing.

**A frame.** In a class, `metres = course.metresAt(frame.time x course seconds / plan seconds)`; in a
race (the frame carries `riders`), `metres = frame.s`, the metres ridden. The rider is
stood at `place(metres)` with the road's heading and slope; the camera sits 4.9 m back and 2.25 m up
on the centre line and looks 14 m ahead, so it follows every bend and crest, and closes in to 3.5 m
and 1.8 m at the start and the finish (L2-166 AC9). The sky dome and the sun's
light ride with the camera. Other riders come from `ridersOnRoad` (as `main`'s) and are stood at
`metres + gap` on their lanes.

**The map's meshes.** The glb holds a few groups, each coloured by vertex and drawn with one cheap material
(no texture, no PBR, shaded flat): `Land`, `Solid`, `Leaves`, `Glow`, `Beams` and `Confetti`, cut into chunks along
the road (`Solid_012`), and `Sea`, `Sun`, `Conillera`, `StartRed` and `StartGreen` whole. Shading is baked into the
colours where the script can (what stands on the ground is darker at its foot). `Glow` and `Beams` are unlit and drawn
past the tone mapping.

**What a frame draws.** Every few frames, and at once when the camera has jumped, each chunk is shown or hidden by
its distance from the camera, by group: the land to 1150 m, solid scenery to 320 m, glow to 430 m, beams to 460 m,
leaves to 210 m, confetti to 300 m; the haze (200 m to 1500 m) covers the rest. No more than the four nearest riders
are drawn. A rider's still parts are merged into one mesh a material, and those of a plain colour into one
vertex-coloured mesh (`merged-cyclist.ts`): some 12 draw calls a rider, not 50. Each rider's shadow is a dark blob
stretched away from the sun; there is no shadow map.

**Tiers.** Cheapest first: 0.75, 1, 1.5 device pixels a CSS pixel, then 1.5 and 2 with a bloom pass over the scene.
The ride opens on 1 with no bloom (L2-111 AC3's rule). Every 90 frames the average frame time is compared with the
display's period: within 1.1 of it, the tier steps up; over 1.6, it steps down and never steps up again.

**Budget (L2-166 AC10).** The worst frame along the course stays within 120,000 triangles and 140 draw calls, and
the map's download within 3 MB gzipped. `docs/screenshots/courses/ibiza/README.md` logs each pass against it.

**Dispose.** Every geometry of the glb and the materials drawn in their place, the sky, the lights, the cyclist
kit, each rider's materials and merged geometries, the shadow blob, the bloom pass and the renderer.

## Tests

- `course.spec.ts`, `course-worlds.spec.ts`: the rules above, case by case.
- `e2e/race-course.spec.ts`: a race on a map whose world is `ibiza` loads `courses/ibiza.glb`, shows
  the renderer's tag, and its picture changes as the clock runs.

## Not yet

- The cadence score (L2-167), a course as a class, and a race's resistance set from the rider's
  place on the course.
- The quality and Graphics API settings (L2-159 to L2-161) and the probe's report on a course.
- A frame rate measured on a real low-power tablet: the budget stands in for it until one is.
- Draco compression of the glb; saving a course for offline (L2-165).
