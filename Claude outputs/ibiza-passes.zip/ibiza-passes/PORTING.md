# Ibiza passes 1 to 13: not applied to the repository

These files are the Ibiza course after 13 performance and look passes. They were made against the
repository as it stood at about 03:45 on 22 Nov. Since then `build_course.py`, `course-renderer.ts`,
`course.ts`, `course-worlds.ts`, `map-renderer.ts`, the README, the design and L2-166 have all been
changed in the repository by other work (themes.py, eight courses, films), so nothing here was
written over them. The paths mirror the repository's.

What to carry over, in order of value:

1. `frontend/projects/world/src/merged-cyclist.ts` (new file) and its two calls in
   `course-renderer.ts` (`mergeStillParts(you, this.plain)`, the `plain` material): 50 draw calls a
   rider become about 12.
2. `course-renderer.ts`: blob shadows in place of the shadow map; `MOST_RIDERS`; the `TIERS` list
   (opens cheap, steps up only at pace); the group materials (`Land`, `Solid`, `Leaves`, `Glow`,
   `Beams`, `Confetti`...), the chunk list and `choose()` with `DRAW_DISTANCE`; `animate()`.
   Meshes that are not named for a group are left as the loader made them, so an unchunked glb
   still draws.
3. `tools/blender/build_course.py`: `PARTS`, `group_of`, `group_material`, `assemble` (every
   Builder hands its faces to the assembly, which welds, colours by vertex and cuts into chunks);
   `GROUNDED` baked shading; boxes with no underside; `gentle()` strips in `build_road`; the pinned
   `layout` (the search for a sea-facing layout takes minutes: the script prints the one it chose).
4. `tools/blender/pack_glb.py` (new file): vertex colours as bytes.
5. The scenery changes of passes 8 and 9 (arched doors, awnings, windows, crowd, palms, sun glow,
   glints) are in `build_scenery` here; in the repository that code may now live in `themes.py`.

The budget and each pass's numbers are in `docs/screenshots/courses/ibiza/README.md`.
